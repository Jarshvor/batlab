===============================================================================
    Roland Dr.Engrave UPGRADE PROGRAM (ver.2.72)
===============================================================================

This program is for upgrading the Dr.Engrave.
It is necessary to have the original Dr.Engrave already installed in order to 
upgrade the program.

	Dr.Engrave ver.1.00 - 2.71  -->  ver.2.72

The upgrade program contains 3 files in 1 folder.  Make sure to copy all the files
in the same folder.  Upgrade will not be completed in case all the files are located
at the different folders.
	+ Updater.exe
	+ Update.dat
	+ readme.txt


-------------------------------------------------------------------------------

1. Operating Environment

 + OS : Windows7(32-bit or 64-bit )/Vista(32-bit or 64-bit )/XP(32-bit or 64-bit )/2000/NT4.0/Me/98/95
        * As this software is a 32-bit application, it runs on WOW64 (or Windows-On-Windows 64) under the 64-bit version of Windows.
 + Old version of the original Dr.Engrave has to be already installed.

2. Upgrade Procedure

 1) Log-on by [Administrator] or [PowerUser] group for Windows2000/NT4.0.
    Log-on by [Administrator] group for Windows7/Vista/XP.
 2) Close all software applications.
 3) Double-click the [Updater] (Updater.exe).
 4) Follow the wizard displayed on the screen.
 5) Click [finish] button to start the upgrade.
 6) Version of the Dr.Engrave can be checked by [Help]/[about] menu in the
    software. 

 + In case the original software is installed besides the default location, the
   Destination Location window displays.  Click on [Browse] and locate the folder
   where the original software is installed.


3. + The format and the name of the help file was changed at ver.2.60.
     This program does not modify the [Start] menu, so you cannot run the newest
     help from the [Start] menu.


-------------------------------------------------------------------------------

* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in 
the United States and/or other countries.

Copyright (C) 2003-2012 Roland DG Corporation

R2-120223
