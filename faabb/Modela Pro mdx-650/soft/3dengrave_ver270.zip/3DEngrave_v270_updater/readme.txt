===============================================================================
    Roland 3D Engrave UPGRADE PROGRAM (ver.2.70)    2012/12/14
===============================================================================

This program is for upgrading the 3D Engrave.
It is necessary to have the original 3D Engrave already installed in order 
to upgrade the program.

	3D Engrave ver.1.00 - 2.66  -->  ver.2.70

The upgrade program contains 5 files in 1 folder.
Make sure to copy all the filesin the same folder.
Upgrade will not be completed in case all the files are located at the different folders.
	+ Updater.exe
	+ Update.dat
	+ Update_cp.dat
	+ UpdateEnv.dll
	+ readme.txt  (, which is this file.) 


-------------------------------------------------------------------------------

1. Operating Environment

 + OS : Windows 8/7/Vista/XP/2000/NT4.0/Me/98/95
        * As this software is a 32-bit application, it runs on WOW64 (or Windows-On-Windows 64) under the 64-bit version of Windows.
 + Old version of the original 3D Engrave has to be already installed.

2. Upgrade Procedure

 1) Log on to Windows as an [Administrator] or a member of the Administrators group.
 2) Close all the software applications.
 3) Double-click the [Updater] (Updater.exe) to start the program.
 4) Follow the wizard displayed on the screen.
 5) Click [finish] button to start the upgrade.
 6) Start 3D Engrave, and go to [HELP] menu to open [about]. Check the version information there to confirm the normal upgrade processing.
 7) After checking the version information, close 3D Engrave. 

 + If the original or older-version software is installed elsewhere than the default location, the Destination Location window may be displayed.
   In such case, click on [Browse] and specify the folder where the original or older-version software has been located.

3. When previewing the file with Virtual MODELA 
   Make sure to use Virtual MODELA ver.1.30 and above.
   Virtual MODELA ver.1.20 and below will not work with the new version of 
   3D Engrave.

4. + The format and the name of the help file was changed at ver.2.50.
     This program does not modify the [Start] menu, so you cannot run the newest
     help from the [Start] menu.


-------------------------------------------------------------------------------

* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.

Copyright (C) 2003-2012 Roland DG Corporation


R2-121214