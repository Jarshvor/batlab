===============================================================================
    Roland DG MODELA Player 4 UPGRADE PROGRAM    
===============================================================================

This program is for upgrading the MODELA Player 4.
It is necessary to have the original MODELA Player 4 already installed in order 
to upgrade the program.

	MODELA Player 4 ver.1.00 - 2.11  --> ver.2.12

The upgrade program contains 4 files in 1 folder.
Make sure to copy all the files in the same folder.
Upgrade will not be completed in case all the files are located at the different folders.
	+ Updater.exe
	+ Update.dat
	+ UpdateEnv.dll
	+ readme.txt


-------------------------------------------------------------------------------

1. Operating Environment

 + OS : Microsoft(R) Windows Vista, Windows 7, or Windows 8 operating system
   * As this software is a 32-bit application, it runs on WOW64 (or Windows-On-Windows 64) under the 64-bit version of Windows.
 + Old version of the original MODELA Player 4 has to be already installed.


2. Upgrade Procedure

 1) Log on to Windows as an [Administrator] or a member of the Administrators group.
 2) Close all the software applications.
 3) Double-click the [Updater] (Updater.exe) to start the program.
 4) Follow the wizard displayed on the screen.
 5) Click [finish] button to start the upgrade.
 6) Start SRP Player, and go to [HELP] menu to open [about]. Check the version information there to confirm the normal upgrade processing.
 7) After checking the version information, close SRP Player. 

 + If the original or older-version software is installed elsewhere than the default location, the Destination Location window may be displayed.
   In such case, click on [Browse] and specify the folder where the original or older-version software has been located.


3. + The IGES file created by Dr.PICZA Ver.2.90 and below can not be opened.
   + When previewing the file with Virtual MODELA, 
     make sure to use Virtual MODELA ver.1.60 and above.
   + Virtual MODELA ver.1.50 and below will not work with the new version of 
     MODELA Player 4.
   + If you are using Windows Vista and are logged on as a different user than the one for which the program was installed and set up, this message may appear when you run the [Preview Cutting] command.
     In such cases, go to the [Start] menu and run Virtual MODELA, then run the [Preview Cutting] command.


-------------------------------------------------------------------------------

* "Windows(R)" is registered trademark or trademark of Microsoft(R) Corporation in the United States and/or other countries.

Copyright (C) 2003-2014 Roland DG Corporation


R4-141121
